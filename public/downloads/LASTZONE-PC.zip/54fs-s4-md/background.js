// =========================================================================
// LAST ZONE - Background Service Worker (Secure Thin Client)
// NO Service Role Keys! All verification runs in Server RPCs
// =========================================================================

const SUPABASE_URL = "https://hdwacqhkfxledujodhft.supabase.co";
const ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imhkd2FjcWhrZnhsZWR1am9kaGZ0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODg0NTc5NjMsImV4cCI6MjEwNDAzMzk2M30.mQFUK_Y2SRLPX1g7MYt6jTgLHMmGKPQB-eleT8rKqeU";

async function generateHardwareDeviceId() {
    try {
        const ua = navigator.userAgent || "";
        const osMatch = ua.match(/\(([^)]+)\)/);
        const osPart = osMatch ? osMatch[1] : (navigator.platform || "unknown-os");
        const cores = navigator.hardwareConcurrency || 0;
        const mem = navigator.deviceMemory || 0;
        const tz = (typeof Intl !== "undefined" && Intl.DateTimeFormat)
            ? (Intl.DateTimeFormat().resolvedOptions().timeZone || "")
            : "";
        const lang = (navigator.languages && navigator.languages[0]) || navigator.language || "";
        const raw = [osPart, cores, mem, tz, lang].join("|");
        const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(raw));
        const hex = Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, "0")).join("");
        return "dev-hw-" + hex.slice(0, 14);
    } catch (_) {
        return "dev-hw-" + (navigator.hardwareConcurrency || 4) + "-" + (navigator.deviceMemory || 8);
    }
}

async function persistDeviceIdEverywhere(deviceId) {
    if (!deviceId) return;
    try { await chrome.storage.local.set({ bruno_device_id: deviceId }); } catch (_) {}
    try { if (chrome.storage.sync) await chrome.storage.sync.set({ bruno_device_id: deviceId }); } catch (_) {}
    try {
        await chrome.cookies.set({
            url: "https://lovable.dev/",
            domain: ".lovable.dev",
            name: "bruno_device_id",
            value: deviceId,
            path: "/",
            secure: true,
            sameSite: "lax",
            expirationDate: Math.floor(Date.now() / 1000) + (10 * 365 * 86400)
        });
    } catch (_) {}
}

async function getDeviceId() {
    try {
        const localData = await chrome.storage.local.get(["bruno_device_id"]);
        if (localData && localData.bruno_device_id && localData.bruno_device_id.startsWith("dev-hw-")) {
            persistDeviceIdEverywhere(localData.bruno_device_id);
            return localData.bruno_device_id;
        }
    } catch (_) {}

    // 1. Recover from lovable.dev persistent cookie (survives extension uninstall/reinstall)
    try {
        const cookie = await chrome.cookies.get({ url: "https://lovable.dev/", name: "bruno_device_id" });
        if (cookie && cookie.value && cookie.value.startsWith("dev-hw-")) {
            await persistDeviceIdEverywhere(cookie.value);
            return cookie.value;
        }
    } catch (_) {}

    // 2. Recover from chrome.storage.sync (survives extension uninstall/reinstall on same Chrome profile)
    try {
        if (chrome.storage.sync) {
            const syncData = await chrome.storage.sync.get(["bruno_device_id"]);
            if (syncData && syncData.bruno_device_id && syncData.bruno_device_id.startsWith("dev-hw-")) {
                await persistDeviceIdEverywhere(syncData.bruno_device_id);
                return syncData.bruno_device_id;
            }
        }
    } catch (_) {}

    // 3. Deterministic Hardware Fingerprint (produces the exact same ID on the same PC even if cookies are cleared)
    const hwId = await generateHardwareDeviceId();
    await persistDeviceIdEverywhere(hwId);
    return hwId;
}

async function verifyLicense(licenseKey) {
    try {
        const cleanKey = String(licenseKey || "").trim().toUpperCase();
        if (!cleanKey) return { ok: false, message: "Please enter a license key" };

        const deviceId = await getDeviceId();
        const res = await fetch(SUPABASE_URL + "/rest/v1/rpc/verify_user_license", {
            method: "POST",
            headers: {
                "apikey": ANON_KEY,
                "Authorization": "Bearer " + ANON_KEY,
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                p_license_key: cleanKey,
                p_device_id: deviceId
            })
        });

        const result = await res.json();
        if (result && result.ok) {
            await chrome.storage.local.set({ bruno_license: result.license });
            return { ok: true, license: result.license };
        } else {
            await chrome.storage.local.remove(["bruno_license"]);
            return { ok: false, message: (result && result.message) || "Invalid or deactivated license key", deactivated: true };
        }
    } catch(e) {
        return { ok: false, message: e.message || "Failed to verify license" };
    }
}

// Clear ONLY the extension's license key, never touch website session
async function logoutLicense() {
    await chrome.storage.local.remove(["bruno_license"]);
    return { ok: true };
}

chrome.runtime.onInstalled.addListener(async () => {
    await getDeviceId();
    await chrome.storage.local.set({ lastzone_chat_server_mode: "server1" });
});

chrome.runtime.onStartup.addListener(async () => {
    const current = await chrome.storage.local.get(["bruno_license"]);
    if (current.bruno_license && current.bruno_license.license_key) {
        await verifyLicense(current.bruno_license.license_key);
    }
});

// =========================================================================
// ACCOUNT SWITCHER ENGINE (Connects to VPS / Local Backend Server)
// =========================================================================
const DEFAULT_SERVER_URL = "http://52.21.185.77:3000";
const DEFAULT_API_KEY = "your-secret-api-key-change-this";

async function getServerConfig() {
    const data = await chrome.storage.local.get(["account_switcher_server_url", "account_switcher_api_key"]);
    let url = data.account_switcher_server_url;
    if (!url || url.includes("localhost") || url.includes("127.0.0.1") || url.includes("44.209.218.68") || !url.includes("52.21.185.77")) {
        url = DEFAULT_SERVER_URL;
        await chrome.storage.local.set({ account_switcher_server_url: DEFAULT_SERVER_URL });
    }
    return {
        serverUrl: url,
        apiKey: data.account_switcher_api_key || DEFAULT_API_KEY
    };
}

async function switchAccount(slotNum, licenseKey, inviteUrl) {
    try {
        // 1. Get license key from argument or local storage
        let key = licenseKey;
        if (!key) {
            const stored = await chrome.storage.local.get(["bruno_license"]);
            if (stored.bruno_license && stored.bruno_license.license_key) {
                key = stored.bruno_license.license_key;
            }
        }

        if (!key) {
            return { ok: false, message: "No active license key found. Please activate your license.", deactivated: true };
        }

        // 2. CHECK DIRECTLY WITH SUPABASE FIRST! If key is invalid or inactive, NEVER touch our VPS server!
        const liveCheck = await verifyLicense(key);
        if (!liveCheck || !liveCheck.ok) {
            await chrome.storage.local.remove(["bruno_license"]);
            return {
                ok: false,
                message: (liveCheck && liveCheck.message) || "Invalid or deactivated license key. Switch blocked.",
                deactivated: true
            };
        }

        const { serverUrl, apiKey } = await getServerConfig();
        console.log(`[LAST ZONE] 🔄 Switch requested for verified License: ${key} via ${serverUrl}...${inviteUrl ? ' with Invite: ' + inviteUrl : ''}`);

        // 3. Multi-tenant: binds or retrieves dedicated account for this user from VPS
        const res = await fetch(`${serverUrl}/api/switch`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "x-api-key": apiKey
            },
            body: JSON.stringify({ licenseKey: key, inviteUrl: inviteUrl || null })
        });

        if (!res.ok) {
            const errData = await res.json().catch(() => ({}));
            const err = new Error(errData.message || errData.error || errData.details || `Server returned error (${res.status})`);
            err.rechargeRequired = (errData.error === "INSUFFICIENT_CREDITS" || res.status === 402);
            err.errorCode = errData.error;
            err.remainingSeconds = errData.remaining_seconds;
            err.cost = errData.cost;
            err.currentCredits = errData.currentCredits;
            if (errData.deactivated || errData.error === "LICENSE_INACTIVE" || errData.error === "LICENSE_NOT_FOUND" || errData.error === "LICENSE_EXPIRED" || res.status === 403) {
                err.deactivated = true;
                await chrome.storage.local.remove(["bruno_license"]);
            }
            throw err;
        }

        const data = await res.json();
        if (!data || !data.success || !data.session) {
            throw new Error("Invalid session response received from server");
        }

        // Update local license credit balance if returned
        if (data.credits !== undefined && key) {
            try {
                const stored = await chrome.storage.local.get(["bruno_license"]);
                if (stored.bruno_license) {
                    stored.bruno_license.credits = data.credits;
                    stored.bruno_license.switch_count = data.switchCount;
                    await chrome.storage.local.set({ bruno_license: stored.bruno_license });
                }
            } catch(_) {}
        }

        const sessionCookies = data.session.cookies || [];
        console.log(`[LAST ZONE] Received ${sessionCookies.length} cookies from server.`);

        if (sessionCookies.length > 0) {
            // VPS returned full browser cookies (e.g. from Playwright) -> clear and inject
            try {
                const allCookies = await chrome.cookies.getAll({});
                for (const c of allCookies) {
                    if (c.domain && c.domain.includes("lovable.dev")) {
                        if (c.name.startsWith("lovable-") || c.name.includes("session") || c.name === "__dpl") {
                            const protocol = c.secure ? "https:" : "http:";
                            const cleanDomain = c.domain.replace(/^\./, "");
                            const url = `${protocol}//${cleanDomain}${c.path || "/"}`;
                            try {
                                await chrome.cookies.remove({ url, name: c.name, storeId: c.storeId });
                            } catch(_) {}
                        }
                    }
                }
                console.log("[LAST ZONE] 🧹 Previous lovable.dev auth cookies cleared.");
            } catch(cookieErr) {
                console.warn("[LAST ZONE] Cookie purge error:", cookieErr);
            }
        } else {
            // Fast-path refresh: DO NOT wipe Cloudflare cookies (__cf_bm, etc.)!
            // Only remove previous auth cookies so fresh session takes over cleanly
            try {
                const authCookies = ["lovable-session-id-v2", "lovable-workspace-id", "lovable-workspace-plan", "lovable-flag-identity", "lovable-flag-attrs", "lovable-flag-plan", "__session"];
                const allCookies = await chrome.cookies.getAll({ domain: "lovable.dev" });
                for (const c of allCookies) {
                    if (authCookies.includes(c.name)) {
                        const protocol = c.secure ? "https:" : "http:";
                        const cleanDomain = c.domain.replace(/^\./, "");
                        await chrome.cookies.remove({
                            url: `${protocol}//${cleanDomain}${c.path || "/"}`,
                            name: c.name,
                            storeId: c.storeId
                        }).catch(() => {});
                    }
                }
                console.log("[LAST ZONE] 🧹 Previous auth session cookies removed (Cloudflare clearance preserved).");
            } catch(_) {}
        }

        // 4. Inject all new cookies
        let injectedCount = 0;
        for (const c of sessionCookies) {
            if (!c.domain || !c.domain.includes("lovable.dev")) continue;

            const protocol = c.secure ? "https:" : "http:";
            const cleanDomain = c.domain.startsWith(".") ? c.domain.substring(1) : c.domain;
            const url = `${protocol}//${cleanDomain}${c.path || "/"}`;

            const details = {
                url,
                name: c.name,
                value: c.value,
                path: c.path || "/",
                secure: c.secure !== undefined ? !!c.secure : true,
                httpOnly: c.httpOnly !== undefined ? !!c.httpOnly : false
            };

            if (c.domain && c.domain.startsWith(".")) {
                details.domain = c.domain;
            }

            if (c.sameSite) {
                const s = String(c.sameSite).toLowerCase();
                if (s === "none" || s === "no_restriction") {
                    details.sameSite = "no_restriction";
                    details.secure = true;
                } else if (s === "lax") {
                    details.sameSite = "lax";
                } else if (s === "strict") {
                    details.sameSite = "strict";
                }
            }

            if (c.expirationDate) {
                details.expirationDate = c.expirationDate;
            }

            try {
                await chrome.cookies.set(details);
                injectedCount++;
            } catch(e) {
                console.warn(`[LAST ZONE] Failed to set cookie ${c.name}:`, e.message);
            }
        }

        console.log(`[LAST ZONE] ✅ Successfully injected ${injectedCount} cookies for account ${data.label || accountId}!`);

        return {
            ok: true,
            accountId: data.accountId,
            email: data.email,
            label: data.label,
            credits: data.credits,
            deductedCredits: data.deductedCredits,
            switchCount: data.switchCount,
            dailySwitchesCount: data.dailySwitchesCount,
            dailySwitchLimit: data.dailySwitchLimit,
            dailySwitchesRemaining: data.dailySwitchesRemaining,
            cooldownSeconds: data.cooldownSeconds,
            cooldownRemainingSeconds: data.cooldownRemainingSeconds,
            lastSwitchAt: data.lastSwitchAt,
            targetUrl: data.targetUrl,
            invitationAccepted: data.invitationAccepted,
            session: {
                localStorage: data.session.localStorage || {},
                token: data.session.token || data.token || null
            }
        };
    } catch(err) {
        console.error("[LAST ZONE] Account switch failed:", err);
        return {
            ok: false,
            message: err.message || "Failed to connect to backend server",
            error: err.errorCode,
            remainingSeconds: err.remainingSeconds,
            rechargeRequired: !!err.rechargeRequired,
            deactivated: !!err.deactivated,
            cost: err.cost,
            currentCredits: err.currentCredits
        };
    }
}

async function getSwitchQuote(licenseKey) {
    try {
        const { serverUrl, apiKey } = await getServerConfig();
        let key = licenseKey;
        if (!key) {
            const stored = await chrome.storage.local.get(["bruno_license"]);
            if (stored.bruno_license && stored.bruno_license.license_key) {
                key = stored.bruno_license.license_key;
            }
        }
        if (!key) return { ok: false, message: "No active license key found", deactivated: true };

        // Verify with Supabase directly first! If invalid, NEVER call VPS!
        const liveCheck = await verifyLicense(key);
        if (!liveCheck || !liveCheck.ok) {
            await chrome.storage.local.remove(["bruno_license"]);
            return {
                ok: false,
                message: (liveCheck && liveCheck.message) || "Invalid or deactivated license key",
                deactivated: true
            };
        }

        const res = await fetch(`${serverUrl}/api/switch/quote?licenseKey=${encodeURIComponent(key)}`, {
            headers: { "x-api-key": apiKey }
        });
        const quote = await res.json().catch(() => ({}));
        if (quote && (quote.deactivated || quote.error === "LICENSE_INACTIVE" || quote.error === "LICENSE_NOT_FOUND" || quote.error === "LICENSE_EXPIRED" || res.status === 403)) {
            quote.deactivated = true;
            await chrome.storage.local.remove(["bruno_license"]);
        }
        return quote;
    } catch(err) {
        return { ok: false, message: err.message || "Failed to reach server" };
    }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.action === "verifyLicense") {
        verifyLicense(msg.key).then(sendResponse);
        return true;
    } else if (msg.action === "verifyLicenseLive") {
        chrome.storage.local.get(["bruno_license"], async (res) => {
            if (res.bruno_license && res.bruno_license.license_key) {
                const check = await verifyLicense(res.bruno_license.license_key);
                if (!check.ok && check.deactivated) {
                    await chrome.storage.local.remove(["bruno_license"]);
                }
                sendResponse(check);
            } else {
                sendResponse({ ok: false, deactivated: false, noLicense: true });
            }
        });
        return true;
    } else if (msg.action === "getLicense") {
        chrome.storage.local.get(["bruno_license"], async (res) => {
            if (res.bruno_license && res.bruno_license.license_key) {
                const check = await verifyLicense(res.bruno_license.license_key);
                if (check.ok) {
                    sendResponse(check.license);
                } else {
                    sendResponse(null);
                }
                return;
            }
            sendResponse(null);
        });
        return true;
    } else if (msg.action === "getDeviceId") {
        getDeviceId().then(sendResponse);
        return true;
    } else if (msg.action === "logoutLicense") {
        logoutLicense().then(sendResponse);
        return true;
    } else if (msg.action === "getSwitchQuote") {
        getSwitchQuote(msg.licenseKey).then(sendResponse);
        return true;
    } else if (msg.action === "switchAccount") {
        switchAccount(msg.slot, msg.licenseKey, msg.inviteUrl).then(sendResponse);
        return true;
    } else if (msg.action === "sendPromptToVps" || msg.action === "backendSendPrompt") {
        sendPromptToVps(msg).then(sendResponse);
        return true;
    } else if (msg.action === "getChatServerMode") {
        chrome.storage.local.get(["lastzone_chat_server_mode"], (res) => {
            const m = res.lastzone_chat_server_mode;
            sendResponse({ ok: true, chatMode: (m === "server1" || m === "routes_root") ? m : "server1" });
        });
        return true;
    } else if (msg.action === "setChatServerMode") {
        const rawMode = String(msg.chatMode || "server1").trim().toLowerCase();
        const mode = (rawMode === "server1" || rawMode === "routes_root") ? rawMode : "server1";
        chrome.storage.local.set({ lastzone_chat_server_mode: mode }).then(() => {
            sendResponse({ ok: true, chatMode: mode });
        });
        return true;
    } else if (msg.action === "getServerConfig") {
        getServerConfig().then(sendResponse);
        return true;
    } else if (msg.action === "setServerConfig") {
        chrome.storage.local.set({
            account_switcher_server_url: msg.serverUrl,
            account_switcher_api_key: msg.apiKey
        }).then(() => sendResponse({ ok: true }));
        return true;
    }
});

// =========================================================================
// LAST ZONE - DUAL SERVER DISPATCHER (PRIMARY & SECONDARY)
// =========================================================================
const CHAT_MODE_ENDPOINTS = {
    server1: "/api/v1/lovable/chat",
    routes_root: "/api/v1/lovable/chat-routes-root"
};

async function sendPromptToVps(reqData) {
    try {
        const message = String(reqData.message || "").trim();
        if (!message) {
            return { ok: false, error: "Empty prompt message" };
        }

        const stored = await chrome.storage.local.get([
            "bruno_license",
            "lastzone_license_key",
            "lovable_pro_license",
            "eu_license_key",
            "ql_license_key",
            "lovable_token",
            "lovable_projectId",
            "lovable_email",
            "lastzone_chat_server_mode"
        ]);
        const lic = stored.bruno_license;
        let key = (lic && lic.license_key) || stored.lastzone_license_key || stored.lovable_pro_license || stored.eu_license_key || stored.ql_license_key || reqData.licenseKey || "";
        if (!key) {
            return { ok: false, error: "No active license key found. Please activate your license first." };
        }

        let projectId = reqData.projectId || stored.lovable_projectId || "";
        if (!projectId) {
            try {
                const tabs = await new Promise((resolve) =>
                    chrome.tabs.query({ active: true, currentWindow: true }, resolve)
                );
                const url = tabs && tabs[0] && tabs[0].url ? tabs[0].url : "";
                const match = url.match(/\/projects\/([a-f0-9-]{36})/i);
                if (match) {
                    projectId = match[1];
                    chrome.storage.local.set({ lovable_projectId: projectId });
                }
            } catch(_) {}
        }

        let token = reqData.token || stored.lovable_token || "";
        if (token.indexOf("Bearer ") === 0) {
            token = token.slice(7);
        }
        if (!token) {
            try {
                const cookieTokens = await new Promise((resolve) => {
                    const names = ["lovable-session-id.id", "lovable-session-id.custom", "lovable-session-id.refresh", "lovable-session-id.sig"];
                    const tokens = [];
                    let done = 0;
                    names.forEach((name) => {
                        chrome.cookies.get({ url: "https://lovable.dev", name }, (cookie) => {
                            done++;
                            if (cookie && cookie.value && cookie.value.indexOf("eyJ") === 0) {
                                tokens.push(cookie.value);
                            }
                            if (done === names.length) resolve(tokens);
                        });
                    });
                });
                if (cookieTokens && cookieTokens.length) {
                    token = cookieTokens[0];
                    chrome.storage.local.set({ lovable_token: token });
                }
            } catch(_) {}
        }

        const { serverUrl, apiKey } = await getServerConfig();
        const primaryVpsUrl = serverUrl || DEFAULT_SERVER_URL;

        const rawMode = String(reqData.chatMode || stored.lastzone_chat_server_mode || "server1").trim().toLowerCase();
        const selectedChatMode = CHAT_MODE_ENDPOINTS[rawMode] ? rawMode : "server1";
        const chatEndpointPath = CHAT_MODE_ENDPOINTS[selectedChatMode] || "/api/v1/lovable/chat";

        console.log(`[LAST ZONE] 🚀 Dispatching prompt to VPS Injection Server [${selectedChatMode.toUpperCase()}]: ${primaryVpsUrl}${chatEndpointPath} (Project ${projectId})...`);

        let vpsRes = null;
        let vpsData = null;
        try {
            vpsRes = await fetch(`${primaryVpsUrl}${chatEndpointPath}`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "x-api-key": apiKey,
                    "x-license-key": key
                },
                body: JSON.stringify({
                    message: message,
                    originalPrompt: reqData.originalPrompt || message,
                    chatMode: selectedChatMode,
                    token: token,
                    licenseKey: key,
                    projectId: projectId,
                    clientGitSha: reqData.clientGitSha || "",
                    id: reqData.id || (reqData.rawBody && reqData.rawBody.id) || null,
                    ai_message_id: reqData.ai_message_id || (reqData.rawBody && reqData.rawBody.ai_message_id) || null,
                    thread_id: reqData.thread_id || (reqData.rawBody && reqData.rawBody.thread_id) || "main",
                    client_id: reqData.client_id || (reqData.rawBody && reqData.rawBody.client_id) || null,
                    files: Array.isArray(reqData.files) ? reqData.files : [],
                    optimisticImageUrls: Array.isArray(reqData.optimisticImageUrls) ? reqData.optimisticImageUrls : [],
                    rawBody: reqData.rawBody || null
                })
            });
            vpsData = await vpsRes.json().catch(() => ({}));
        } catch(vpsErr) {
            console.warn("[LAST ZONE] VPS fetch failed:", vpsErr);
        }

        if (vpsRes && (vpsRes.ok || vpsRes.status === 202 || (vpsData && vpsData.ok))) {
            const rem = (vpsData && (vpsData.credits !== undefined ? vpsData.credits : vpsData.creditsRemaining)) ?? 9999;
            if (lic) {
                lic.credits = rem;
                await chrome.storage.local.set({ bruno_license: lic });
            }
            return {
                ok: true,
                status: 202,
                accepted: true,
                creditsRemaining: rem
            };
        }

        if (vpsRes && vpsData && (vpsData.error || vpsData.message)) {
            return {
                ok: false,
                status: vpsRes.status || 400,
                error: vpsData.message || vpsData.error
            };
        }

        const errMsg = (vpsData && (vpsData.error || vpsData.message)) || "VPS chat injection failed";
        return {
            ok: false,
            status: (vpsRes && vpsRes.status) || 502,
            error: errMsg
        };
    } catch (err) {
        console.error("[LAST ZONE] Prompt Dispatch exception:", err);
        return {
            ok: false,
            status: 502,
            error: err.message || "Failed to inject chat prompt"
        };
    }
}

