document.addEventListener("DOMContentLoaded", () => {
    const keyInput = document.getElementById("keyInput");
    const activateBtn = document.getElementById("activateBtn");
    const statusMsg = document.getElementById("statusMsg");

    const serverUrlInput = document.getElementById("serverUrlInput");
    const saveServerBtn = document.getElementById("saveServerBtn");
    const serverStatusBadge = document.getElementById("serverStatusBadge");

    // Select Server (Primary [Default] & Secondary)
    const CHAT_SERVERS = [
        { id: "server1", shortLabel: "Primary", badgeLabel: "Primary", title: "Primary Server", color: "#3b82f6" },
        { id: "routes_root", shortLabel: "Secondary", badgeLabel: "Secondary", title: "Secondary Server", color: "#22c55e" }
    ];

    const popupServerGrid = document.getElementById("popupServerGrid");
    const popupChatModeBadge = document.getElementById("popupChatModeBadge");

    if (popupServerGrid) {
        popupServerGrid.innerHTML = CHAT_SERVERS.map(s => `
            <button id="popup-mode-${s.id}-btn" type="button" title="${s.title}" style="background: #10172e; border: 1px solid #1c2e54; color: #9e97bd; border-radius: 8px; padding: 9px 10px; font-size: 11.5px; font-weight: 800; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 7px; transition: all 0.2s;">
                <span id="popup-mode-${s.id}-dot" style="width: 8px; height: 8px; border-radius: 50%; background: ${s.color}; box-shadow: 0 0 6px ${s.color}; display: inline-block; flex-shrink: 0;"></span>
                <span>${s.shortLabel}</span>
            </button>
        `).join("");

        CHAT_SERVERS.forEach(s => {
            const btn = document.getElementById(`popup-mode-${s.id}-btn`);
            if (btn) {
                btn.addEventListener("click", () => {
                    chrome.runtime.sendMessage({ action: "setChatServerMode", chatMode: s.id }, () => {
                        renderPopupChatMode(s.id);
                    });
                });
            }
        });
    }

    function renderPopupChatMode(mode) {
        const activeCfg = CHAT_SERVERS.find(s => s.id === mode) || CHAT_SERVERS[0];

        CHAT_SERVERS.forEach(s => {
            const btn = document.getElementById(`popup-mode-${s.id}-btn`);
            const dot = document.getElementById(`popup-mode-${s.id}-dot`);
            const isActive = (s.id === activeCfg.id);
            const isBlue = (s.color === "#3b82f6");

            if (btn) {
                if (isActive) {
                    btn.style.background = isBlue
                        ? "linear-gradient(135deg, rgba(59, 130, 246, 0.28), rgba(37, 99, 235, 0.16))"
                        : "linear-gradient(135deg, rgba(34, 197, 94, 0.28), rgba(16, 185, 129, 0.16))";
                    btn.style.border = `1.5px solid ${s.color}`;
                    btn.style.color = "#ffffff";
                    btn.style.boxShadow = isBlue
                        ? "0 0 12px rgba(59, 130, 246, 0.35)"
                        : "0 0 12px rgba(34, 197, 94, 0.35)";
                } else {
                    btn.style.background = "#10172e";
                    btn.style.border = "1px solid #1c2e54";
                    btn.style.color = "#9e97bd";
                    btn.style.boxShadow = "none";
                }
            }
            if (dot) {
                dot.style.background = s.color;
                dot.style.opacity = isActive ? "1" : "0.85";
                dot.style.boxShadow = isActive ? `0 0 8px ${s.color}` : `0 0 4px ${s.color}66`;
            }
        });

        if (popupChatModeBadge) {
            const isBlue = (activeCfg.color === "#3b82f6");
            popupChatModeBadge.textContent = activeCfg.badgeLabel;
            popupChatModeBadge.style.color = isBlue ? "#60a5fa" : "#4ade80";
            popupChatModeBadge.style.background = isBlue ? "rgba(59, 130, 246, 0.16)" : "rgba(34, 197, 94, 0.16)";
            popupChatModeBadge.style.borderColor = isBlue ? "rgba(59, 130, 246, 0.45)" : "rgba(34, 197, 94, 0.45)";
        }
    }

    chrome.runtime.sendMessage({ action: "getChatServerMode" }, (res) => {
        renderPopupChatMode((res && res.chatMode) || "server1");
    });

    // Pre-fill key if saved
    chrome.runtime.sendMessage({ action: "getLicense" }, (lic) => {
        if (lic && lic.license_key) {
            keyInput.value = lic.license_key;
        }
    });

    // Server Config & Health Check
    function checkServerHealth(url) {
        if (!serverStatusBadge) return;
        serverStatusBadge.textContent = "Connecting...";
        serverStatusBadge.style.color = "#ffa502";
        serverStatusBadge.style.background = "rgba(255,165,2,0.2)";

        fetch(`${url}/health`, { method: "GET" })
            .then(r => r.json())
            .then(data => {
                if (data && data.status === "ok") {
                    serverStatusBadge.textContent = "🟢 Online";
                    serverStatusBadge.style.color = "#00d2d3";
                    serverStatusBadge.style.background = "rgba(0,210,211,0.2)";
                } else {
                    throw new Error("Invalid status");
                }
            })
            .catch(() => {
                serverStatusBadge.textContent = "🔴 Offline";
                serverStatusBadge.style.color = "#ff4757";
                serverStatusBadge.style.background = "rgba(255,71,87,0.2)";
            });
    }

    chrome.runtime.sendMessage({ action: "getServerConfig" }, (cfg) => {
        if (cfg && cfg.serverUrl) {
            if (serverUrlInput) serverUrlInput.value = cfg.serverUrl;
            checkServerHealth(cfg.serverUrl);
        }
    });

    if (saveServerBtn && serverUrlInput) {
        saveServerBtn.addEventListener("click", () => {
            const url = (serverUrlInput.value.trim() || "http://52.21.185.77:3000").replace(/\/+$/, "");
            saveServerBtn.textContent = "...";
            chrome.runtime.sendMessage({
                action: "setServerConfig",
                serverUrl: url,
                apiKey: "your-secret-api-key-change-this"
            }, () => {
                saveServerBtn.textContent = "Saved";
                setTimeout(() => saveServerBtn.textContent = "Save", 1500);
                checkServerHealth(url);
            });
        });
    }

    activateBtn.addEventListener("click", () => {
        const key = keyInput.value.trim();
        if (!key) return;

        activateBtn.disabled = true;
        activateBtn.textContent = "Activating...";
        statusMsg.style.display = "none";

        chrome.runtime.sendMessage({ action: "verifyLicense", key }, (res) => {
            activateBtn.disabled = false;
            activateBtn.textContent = "Activate License";
            statusMsg.style.display = "block";

            if (res && res.ok) {
                statusMsg.className = "status-msg status-success";
                statusMsg.textContent = "✓ License Activated Successfully!";
            } else {
                statusMsg.className = "status-msg status-error";
                statusMsg.textContent = "✗ " + ((res && res.message) || "Activation Failed");
            }
        });
    });
});
