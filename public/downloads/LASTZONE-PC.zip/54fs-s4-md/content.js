// =========================================================================
// LAST ZONE - Content Script (ISOLATED World)
// Bridges license & device credentials to in-page inject.js
// =========================================================================

(function() {
    if (window.__lastZoneIsolatedInstalled) return;
    window.__lastZoneIsolatedInstalled = true;

    function injectMainScript() {
        try {
            const script = document.createElement("script");
            script.src = chrome.runtime.getURL("inject.js");
            script.onload = function() { this.remove(); };
            script.onerror = function() {
                fetch(chrome.runtime.getURL("inject.js"))
                    .then(r => r.text())
                    .then(code => {
                        const inline = document.createElement("script");
                        inline.textContent = code;
                        (document.head || document.documentElement).appendChild(inline);
                        inline.remove();
                    });
            };
            (document.head || document.documentElement).appendChild(script);
        } catch(e) {
            console.error("[LAST ZONE] Script injection error:", e);
        }
    }

    function syncLicenseData() {
        try {
            chrome.storage.local.get(["bruno_license", "bruno_device_id", "bruno_invite_url", "lovable_pro_license", "lastzone_license_key", "lastzone_chat_server_mode"], (res) => {
                const lic = res.bruno_license || null;
                const licKey = lic?.license_key || res.lastzone_license_key || res.lovable_pro_license || "";
                if (licKey) {
                    try {
                        localStorage.setItem("lastzone_license_key", licKey);
                        localStorage.setItem("lovable_pro_license", licKey);
                    } catch(_) {}
                }
                let devId = (res.bruno_device_id && res.bruno_device_id.startsWith("dev-hw-")) ? res.bruno_device_id : "";
                try {
                    const lsDevId = localStorage.getItem("bruno_device_id") || localStorage.getItem("lastzone_device_id") || "";
                    if (lsDevId && lsDevId.startsWith("dev-hw-")) {
                        if (!devId || devId !== lsDevId) {
                            devId = lsDevId;
                            chrome.storage.local.set({ bruno_device_id: lsDevId });
                        }
                    } else if (devId) {
                        localStorage.setItem("bruno_device_id", devId);
                        localStorage.setItem("lastzone_device_id", devId);
                    }
                } catch(_) {}
                const savedMode = res.lastzone_chat_server_mode || localStorage.getItem("lastzone_chat_server_mode") || "server1";
                const validMode = (savedMode === "server1" || savedMode === "routes_root") ? savedMode : "server1";
                try { localStorage.setItem("lastzone_chat_server_mode", validMode); } catch(_) {}
                window.postMessage({
                    type: "LASTZONE_DATA_SYNC",
                    license: lic || (licKey ? { license_key: licKey, credits: 9999 } : null),
                    deviceId: devId || "dev-default",
                    inviteUrl: res.bruno_invite_url || "",
                    chatMode: validMode
                }, "*");
            });
        } catch(_) {}
    }

    window.addEventListener("message", (ev) => {
        if (ev.source !== window || !ev.data) return;
        if (ev.data.type === "LASTZONE_REQUEST_DATA" || ev.data.type === "BRUNO_REQUEST_DATA") {
            syncLicenseData();
        }
        if (ev.data.type === "LASTZONE_SET_CHAT_MODE") {
            const rawMode = String(ev.data.chatMode || "server1").trim().toLowerCase();
            const mode = (rawMode === "server1" || rawMode === "routes_root") ? rawMode : "server1";
            try {
                localStorage.setItem("lastzone_chat_server_mode", mode);
                chrome.storage.local.set({ lastzone_chat_server_mode: mode }, () => {
                    window.postMessage({ type: "LASTZONE_CHAT_MODE_SAVED", chatMode: mode }, "*");
                });
            } catch(_) {}
        }
        if (ev.data.type === "LASTZONE_SAVE_INVITE_URL") {
            const url = (ev.data.inviteUrl !== undefined && ev.data.inviteUrl !== null) ? String(ev.data.inviteUrl).trim() : "";
            try {
                chrome.storage.local.set({ bruno_invite_url: url }, () => {
                    window.postMessage({ type: "LASTZONE_INVITE_URL_SAVED", inviteUrl: url }, "*");
                });
            } catch(_) {}
        }
        if (ev.data.type === "LASTZONE_LOGOUT") {
            chrome.runtime.sendMessage({ action: "logoutLicense" }, () => {
                window.postMessage({ type: "LASTZONE_LOGOUT_SUCCESS" }, "*");
            });
        }
        if (ev.data.type === "LASTZONE_VERIFY_KEY") {
            chrome.runtime.sendMessage({ action: "verifyLicense", key: ev.data.key }, (result) => {
                window.postMessage({ type: "LASTZONE_VERIFY_RESULT", result: result }, "*");
                if (result && result.ok) {
                    syncLicenseData();
                }
            });
        }
        if (ev.data.type === "LASTZONE_GET_SWITCH_QUOTE" || ev.data.type === "LASTZONE_GET_SWITCH_POLICY") {
            chrome.runtime.sendMessage({
                action: "getSwitchQuote",
                licenseKey: ev.data.licenseKey
            }, (result) => {
                window.postMessage({ type: ev.data.type === "LASTZONE_GET_SWITCH_POLICY" ? "LASTZONE_POLICY_RESULT" : "LASTZONE_QUOTE_RESULT", result: result }, "*");
            });
        }
        if (ev.data.type === "LASTZONE_TRIGGER_SWITCH") {
            chrome.runtime.sendMessage({
                action: "switchAccount",
                slot: ev.data.slot,
                licenseKey: ev.data.licenseKey,
                inviteUrl: ev.data.inviteUrl || null
            }, (result) => {
                window.postMessage({ type: "LASTZONE_SWITCH_RESULT", result: result }, "*");
            });
        }
        if (ev.data.type === "LASTZONE_INJECT_CHAT" || ev.data.type === "lovableBackendChatRequest") {
            const reqId = ev.data.requestId;
            if (window._lzHandledChatRequests && window._lzHandledChatRequests.has(reqId)) {
                return;
            }
            if (!window._lzHandledChatRequests) {
                window._lzHandledChatRequests = new Set();
            }
            window._lzHandledChatRequests.add(reqId);
            if (window._lzHandledChatRequests.size > 200) {
                const first = window._lzHandledChatRequests.values().next().value;
                window._lzHandledChatRequests.delete(first);
            }

            const payload = ev.data.payload || ev.data;
            if (payload.token) {
                try { chrome.storage.local.set({ lovable_token: payload.token }); } catch(_) {}
            }
            if (payload.projectId) {
                try { chrome.storage.local.set({ lovable_projectId: payload.projectId }); } catch(_) {}
            }
            chrome.runtime.sendMessage({
                action: "backendSendPrompt",
                message: payload.message,
                originalPrompt: payload.originalPrompt || payload.message,
                token: payload.token,
                projectId: payload.projectId,
                clientGitSha: payload.clientGitSha,
                id: payload.id,
                ai_message_id: payload.ai_message_id,
                thread_id: payload.thread_id,
                client_id: payload.client_id,
                files: payload.files,
                optimisticImageUrls: payload.optimisticImageUrls,
                rawBody: payload.rawBody,
                chatMode: payload.chatMode || localStorage.getItem("lastzone_chat_server_mode") || "server1"
            }, (result) => {
                window.postMessage({
                    type: "LASTZONE_CHAT_RESULT",
                    requestId: reqId,
                    result: result || { ok: false, error: "No response from extension background" }
                }, "*");
                window.postMessage({
                    type: "lovableBackendChatResult",
                    requestId: reqId,
                    result: result || { ok: false, error: "No response from extension background" }
                }, "*");
                if (result && (result.creditsRemaining !== undefined || result.credits !== undefined)) {
                    syncLicenseData();
                }
            });
        }
    });

    function checkLiveLicense() {
        try {
            chrome.runtime.sendMessage({ action: "verifyLicenseLive" }, (res) => {
                if (res && !res.ok && res.deactivated) {
                    window.postMessage({
                        type: "LASTZONE_FORCE_LOGOUT",
                        message: res.message || "License deactivated by administrator"
                    }, "*");
                }
            });
        } catch(_) {}
    }

    chrome.runtime.onMessage.addListener((msg) => {
        if (msg.action === "forceLicenseLogout") {
            window.postMessage({
                type: "LASTZONE_FORCE_LOGOUT",
                message: msg.message || "License deactivated by administrator"
            }, "*");
        }
    });

    chrome.storage.onChanged.addListener((changes, area) => {
        if (area === "local" && (changes.bruno_license || changes.bruno_device_id || changes.bruno_invite_url || changes.lastzone_chat_server_mode)) {
            syncLicenseData();
        }
    });

    const LZ_TROUBLESHOOT_HTML = `
<div class="lz-options-box" data-lz-options-rendered="true" style="margin: 6px 0; font-family: inherit; font-size: 13px; line-height: 1.6; display: flex; flex-direction: column; gap: 4px;" dir="ltr">
  <div style="color: #ef4444; font-weight: 500;">🔴 Option 1: Stop immediately and resend your message. If that doesn't work, try again; if it still fails, proceed to Option 2.</div>
  <div style="color: #10b981; font-weight: 500;">🟢 Option 2: Change the server from the primary one; if that doesn't work, proceed to Option 3.</div>
  <div style="color: #3b82f6; font-weight: 500;">🔵 Option 3: Switch to another account using the switch button and continue your work.</div>
</div>
`.trim();

    function replaceTroubleshootDOM(root) {
        try {
            const scope = root || document;
            if (!scope.querySelectorAll) return;
            const candidates = scope.querySelectorAll('p, span, div, code, pre');
            candidates.forEach(el => {
                if (el.closest("#ds-floating-widget") || el.closest("#ds-server-switch-overlay") || el.closest(".lz-options-box")) return;
                const rawTxt = (el.textContent || "").trim();
                if (!rawTxt) return;

                if (/For\s+the\s+code\s+present/i.test(rawTxt)) {
                    const childHas = Array.from(el.children).some(c => /For\s+the\s+code\s+present/i.test(c.textContent || ""));
                    if (childHas) return;
                    if (!el.querySelector(".lz-options-box")) {
                        el.setAttribute("data-lz-options-rendered", "true");
                        el.innerHTML = LZ_TROUBLESHOOT_HTML;
                    }
                } else if (/Please\s+think\s+step-by-step/i.test(rawTxt)) {
                    const childHas = Array.from(el.children).some(c => /Please\s+think\s+step-by-step/i.test(c.textContent || ""));
                    if (childHas) return;
                    el.textContent = "";
                    el.style.display = "none";
                }
            });
        } catch(_) {}
    }

    // Special message label renderer (Replaces Fix build error / special-message with LAST ZONE ....)
    const BRAND_TEXT = "LAST ZONE ....";
    const BRAND_COLOR = "#d946ef";

    function applyBrandToElement(el) {
        if (!el) return;
        if (el.textContent !== BRAND_TEXT) {
            el.textContent = BRAND_TEXT;
        }
        el.style.setProperty("color", BRAND_COLOR, "important");
        el.style.setProperty("font-weight", "bold", "important");
    }

    const ERROR_TEXT_CHECK_RX = /(?:error\s+TS\d+|not\s+assignable\s+to\s+type|does\s+not\s+exist\s+on\s+type|\bProperty\b)/i;

    function stripEnglishErrorText(str) {
        if (!str || typeof str !== "string") return str;
        return str
            .replace(/(?:src\/[A-Za-z0-9_./-]+(?:\(\d+,\d+\))?:\s*)?error\s+TS\d+:\s*Type\s+['"][^'"]+['"]\s+is\s+not\s+assignable\s+to\s+type\s+['"][^'"]+['"]\.?/gi, "")
            .replace(/(?:src\/[A-Za-z0-9_./-]+(?:\(\d+,\d+\))?:\s*)?error\s+TS\d+:\s*Property\s*['"]?/gi, "")
            .replace(/(?:src\/[A-Za-z0-9_./-]+(?:\(\d+,\d+\))?:\s*)?error\s+TS\d+:?\s*/gi, "")
            .replace(/Type\s+['"][^'"]+['"]\s+is\s+not\s+assignable\s+to\s+type\s+['"][^'"]+['"]\.?/gi, "")
            .replace(/\bProperty\s*['"]?(?=[\s\S]*does\s+not\s+exist\s+on\s+type)/gi, "")
            .replace(/^\s*Property\s*['"]?/gm, "")
            .replace(/['"]?\s*does\s+not\s+exist\s+on\s+type\s+['"][^'"]+['"]\.?/gi, "");
    }

    function clearErrorTextNodes(root) {
        try {
            const scope = root || document.body || document.documentElement;
            if (!scope) return;
            if (scope.nodeType === Node.TEXT_NODE) {
                const val = scope.nodeValue;
                if (val && ERROR_TEXT_CHECK_RX.test(val)) {
                    const cleaned = stripEnglishErrorText(val);
                    if (cleaned !== val) scope.nodeValue = cleaned;
                }
                return;
            }
            const walker = document.createTreeWalker(scope, NodeFilter.SHOW_TEXT, null);
            let node;
            while ((node = walker.nextNode())) {
                const val = node.nodeValue;
                if (val && ERROR_TEXT_CHECK_RX.test(val)) {
                    const p = node.parentElement;
                    if (p && (p.closest("#ds-floating-widget") || p.closest("#ds-server-switch-overlay") || p.tagName === "SCRIPT" || p.tagName === "STYLE" || p.tagName === "TEXTAREA")) continue;
                    const cleaned = stripEnglishErrorText(val);
                    if (cleaned !== val) node.nodeValue = cleaned;
                }
            }
        } catch (_) {}
    }

    function renderSpecialMessages() {
        try {
            clearErrorTextNodes(document.body);
            document.querySelectorAll(".special-message, [class*='special-message']").forEach((m) => {
                applyBrandToElement(m);
            });
            document.querySelectorAll("button, span, p, div, [role='button']").forEach((el) => {
                if (el.closest("#ds-floating-widget") || el.closest("#ds-server-switch-overlay")) return;
                const txt = (el.textContent || "").trim();
                if (el.children.length === 0 && (/Fix\s*build\s*errors?/i.test(txt) || txt === "Lovable")) {
                    applyBrandToElement(el);
                }
            });
        } catch(_) {}
    }

    function startSpecialMessageObserver() {
        renderSpecialMessages();
        replaceTroubleshootDOM();
        try {
            const obs = new MutationObserver((mutations) => {
                mutations.forEach((mut) => {
                    if (mut.type === "characterData") {
                        clearErrorTextNodes(mut.target);
                        const m = mut.target.parentElement?.closest(".special-message, [class*='special-message']");
                        if (m) applyBrandToElement(m);
                        const txt = (mut.target.textContent || "").trim();
                        if (/Fix\s*build\s*errors?/i.test(txt) || txt === "Lovable") {
                            applyBrandToElement(mut.target.parentElement);
                        }
                        replaceTroubleshootDOM(mut.target.parentElement);
                        return;
                    }
                    mut.addedNodes.forEach((n) => {
                        if (n.nodeType === Node.TEXT_NODE) {
                            clearErrorTextNodes(n);
                        } else if (n.nodeType === Node.ELEMENT_NODE) {
                            clearErrorTextNodes(n);
                            if (n.matches && n.matches(".special-message, [class*='special-message']")) {
                                applyBrandToElement(n);
                            }
                            n.querySelectorAll?.(".special-message, [class*='special-message']").forEach(el => {
                                applyBrandToElement(el);
                            });
                            n.querySelectorAll?.("button, span, [role='button']").forEach(el => {
                                if (el.children.length === 0) {
                                    const txt = (el.textContent || "").trim();
                                    if (/Fix\s*build\s*errors?/i.test(txt) || txt === "Lovable") {
                                        applyBrandToElement(el);
                                    }
                                }
                            });
                            replaceTroubleshootDOM(n);
                        }
                    });
                });
            });
            obs.observe(document.documentElement, { childList: true, characterData: true, subtree: true });
        } catch(_) {}
    }

    window.addEventListener("focus", checkLiveLicense);
    document.addEventListener("visibilitychange", () => {
        if (!document.hidden) checkLiveLicense();
    });

    setInterval(checkLiveLicense, 10000);

    injectMainScript();
    syncLicenseData();
    checkLiveLicense();
    startSpecialMessageObserver();
    setInterval(replaceTroubleshootDOM, 1000);
    setInterval(renderSpecialMessages, 800);
})();
